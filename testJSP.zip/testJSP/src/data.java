

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class data extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String id=request.getParameter("id");
		String fname=request.getParameter("fname");
		String lname= request.getParameter("lname");
		String email=request.getParameter("email");
		out.print("<center><b>Welcome:"+fname+lname+"</b></center>");
      
		Map<String, List<String>> map = (Map<String, List<String>>) new HashMap<String, List<String>>();
		 

	
	     
	     List<String> three = new ArrayList<String>();
	     three.add(fname);
	     three.add(lname);
	     three.add(email);
	     
	     
	  

	     map.put(id, three);
	
	     
	     
	     out.println("<html><head><style>"
	      		+ "table {\r\n" + 
	      		"    border-collapse: collapse;\r\n" + 
	      		"    width: 100%;\r\n" + 
	      		"}\r\n" + 
	      		"\r\n" + 
	      		"th, td {\r\n" + 
	      		"    text-align: left;\r\n" + 
	      		"    padding: 8px;\r\n" + 
	      		"}\r\n" + 
	      		"\r\n" 
	      		+ "</style></head><body><table>");
	      out.println("<tr>");
	      out.println("<th>Emp Id</th>");
	      out.println("<th>Emp FirstName</th>");
	      out.println("<th>Emp LastName</th>");
	      out.println("<th>Emp Email</th>");
	      
	     out.println("</tr>");

	     for (Map.Entry<String, List<String>> entry : map.entrySet()) {
	          String key = entry.getKey();
	          List<String> values = entry.getValue();
	          
	          out.println("<tr class=\"wrap\">");
	          out.println("<td>"+key+"</td>");
	          out.println("<td>"+values.get(0)+"</td>");
	          out.println("<td>"+values.get(1)+"</td>");
	          out.println("<td>"+values.get(2)+"</td>");
	          out.println("<td>"+values.get(3)+"</td>");
	      
	          out.println("</table></body></html>");
		        
	       
	      }
	 	
	    
	
	      
		
		

	}

}




//
//
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//
//public class data extends HttpServlet {
//	private static final long serialVersionUID = 1L;
//       
//  
//	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		
//
//		response.setContentType("text/html");
//		PrintWriter out=response.getWriter();
//		String fname=request.getParameter("fname");
//		String lname=request.getParameter("lname");
//		String email=request.getParameter("email");
//		String id=request.getParameter("id");
//		
// Map<String, List<String>> map = (Map<String, List<String>>) new HashMap<String, List<String>>();
//		 
//	     List<String> one = new ArrayList<String>();
//	     one.add("Ramanjit");
//	    one.add("Kaur");
//	     one.add("raman@gmail.com");
//	     
//	     List<String> two = new ArrayList<String>();
//	     two.add("Ramanjit");
//	     two.add("Kaur");
//	     two.add("raman@gmail.com");
//	     
//	     List<String> three = new ArrayList<String>();
//	     three.add("Ramanjit");
//	     three.add("Kaur");
//	     three.add("raman@gmail.com");
//	     
//	     List<String> four = new ArrayList<String>();
//	   
//	     four.add("Ramanjit");
//	     four.add("Kaur");
//	     four.add("raman@gmail.com");
//	     
//	 
//	     
//	     List<String> newData = new ArrayList<String>();
//	     
//	     newData.add(fname);
//	     newData.add(lname);
//	     newData.add(email);
//	    
//	     
//	     map.put("1001", one);
//	     map.put("1012",two);
//	     map.put("1022", three);
//	     map.put("1032", four);
//	     map.put(id,newData);
//	    
//	     
//	     
//	     out.println("<html><head><style>"
//		      		+ "table {\r\n" + 
//		      		"    border-collapse: collapse;\r\n" + 
//		      		"    width: 100%;\r\n" + 
//		      		"}\r\n" + 
//		      		"\r\n" + 
//		      		"th, td {\r\n" + 
//		      		"    text-align: left;\r\n" + 
//		      		"    padding: 8px;\r\n" + 
//		      		"}\r\n" + 
//		      		"\r\n" 
//		      		+ "</style></head><body><table>");
//		      out.println("<tr>");
//		      out.println("<th>Emp Id</th>");
//		      out.println("<th>Emp First Name</th>");
//		      out.println("<th>Emp Last Name</th>");
//		      out.println("<th>Emp Email</th>");
//		      
//		     out.println("</tr>");
//	
//		      for (Map.Entry<String, List<String>> entry : map.entrySet()) {
//		          String key = entry.getKey();
//		          List<String> values = entry.getValue();
//		          
//		          out.println("<tr class=\"wrap\">");
//		          out.println("<td>"+key+"</td>");
//		          out.println("<td>"+values.get(0)+"</td>");
//		          out.println("<td>"+values.get(1)+"</td>");
//		          out.println("<td>"+values.get(2)+"</td>");
//		          out.println("<td>"+values.get(3)+"</td>");
//		         
//		        
//		         out.println("</tr>");
//		      
//		      
//		      
//		      }
//		 	
//	        out.println("</table></body></html>"); }}
//			
//			
//
//
//		
//	
////		Map<String, List<String>> map = (Map<String, List<String>>) new HashMap<String, List<String>>();
////		 
////	     ArrayList<String> one = new ArrayList<String>();
////	     one.add(fname);
////	     one.add(lname);
////	     one.add(email);
////	     map.put(id, one);
////	
////	   
////	     
////	     
////	     out.println("<html><head><style>"
////	      		+ "table {\r\n" + 
////	      		"    border-collapse: collapse;\r\n" + 
////	      		"    width: 100%;\r\n" + 
////	      		"}\r\n" + 
////	      		"\r\n" + 
////	      		"th, td {\r\n" + 
////	      		"    text-align: left;\r\n" + 
////	      		"    padding: 8px;\r\n" + 
////	      		"}\r\n" + 
////	      		"\r\n" 
////	      		+ "</style></head><body><table>");
////	      out.println("<tr>");
////	      out.println("<th>Emp Id</th>");
////	      out.println("<th>Emp First Name</th>");
////	      out.println("<th>Emp Last Name</th>");
////	      out.println("<th>Emp Email</th>");
////	      
////	     out.println("</tr>");
////
////	      for (Map.Entry<String, List<String>> entry : map.entrySet()) {
////	          String key = entry.getKey();
////	          List<String> values = entry.getValue();
////	          
////	          out.println("<tr class=\"wrap\">");
////	          out.println("<td>"+key+"</td>");
////	          out.println("<td>"+values.get(0)+"</td>");
////	          out.println("<td>"+values.get(1)+"</td>");
////	          out.println("<td>"+values.get(2)+"</td>");
////	          out.println("<td>"+values.get(3)+"</td>");
////	         
////	        
////	         out.println("</tr>");
////	      
////	      
////	      
////	      }
////	 	
////	        out.println("</table></body></html>");
//		
//		
//
