

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class welcome extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String uname=request.getParameter("uname");
		out.print("<center><h1>Welcome:"+uname+"</h1></center>");
	
		
		out.print("<form action=\"");
		out.print(response.encodeURL("form.html"));
		out.print("\" ");
		out.println("method=POST>");
	    out.println("<br>");
		out.println("<center><input type=submit value=\"Click to add Details\"></center>");
		out.println("</form>");
	}

}


