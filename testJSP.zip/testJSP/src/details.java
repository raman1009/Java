

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class details extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		

		Map<String, List<String>> map = (Map<String, List<String>>) new HashMap<String, List<String>>();
		 
	     List<String> one = new ArrayList<String>();
	     one.add("John");
	     one.add("Singh");
	     one.add("John@gmail.com");
	   
	     
	     List<String> two = new ArrayList<String>();
	     two.add("Marry");
	     two.add("Kaur");
	     two.add("Mary@gmail.com");
	     
	     
	     
	     map.put("100", one);
	     map.put("101",two);
	     
	     
	     out.println("<html><head><style>"
		      		+ "table {\r\n" + 
		      		"    border-collapse: collapse;\r\n" + 
		      		"    width: 100%;\r\n" + 
		      		"}\r\n" + 
		      		"\r\n" + 
		      		"th, td {\r\n" + 
		      		"    text-align: left;\r\n" + 
		      		"    padding: 8px;\r\n" + 
		      		"}\r\n" + 
		      		"\r\n" 
		      		+ "</style></head><body><table>");
		      out.println("<tr>");
		      out.println("<th>Emp Id</th>");
		      out.println("<th>Emp FirstName</th>");
		      out.println("<th>Emp LastName</th>");
		      out.println("<th>Emp Email</th>");
		      
		     out.println("</tr>");

		     for (Map.Entry<String, List<String>> entry : map.entrySet()) {
		          String key = entry.getKey();
		          List<String> values = entry.getValue();
		          
		          out.println("<tr class=\"wrap\">");
		          out.println("<td>"+key+"</td>");
		          out.println("<td>"+values.get(0)+"</td>");
		          out.println("<td>"+values.get(1)+"</td>");
		          out.println("<td>"+values.get(2)+"</td>");
		          out.println("<td>"+values.get(3)+"</td>");
		      
		      
	}

}}
