

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class login extends HttpServlet {
	
	
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String fname= request.getParameter("fname");
		String lname= request.getParameter("lname");
		String email= request.getParameter("email");
		
		
		out.print("<center><b>Welcome:"+fname+lname+"</b></center>");
		out.print("<br>");
		
		
		
		
		out.print("<center><b>Email:"+email+"</b></center>");
	    
		Map<String, List<String>> map = (Map<String, List<String>>) new HashMap<String, List<String>>();
		 
	     List<String> one = new ArrayList<String>();
	     one.add("John");
	     one.add("22");
	     one.add("Training");
	     one.add("16000");
	     
	     List<String> two = new ArrayList<String>();
	     two.add("Marry");
	     two.add("28");
	     two.add("Learning & Development");
	     two.add("50000");
	     
	     List<String> three = new ArrayList<String>();
	     three.add("Mark");
	     three.add("52");
	     three.add("Development");
	     three.add("80000");
	     
	     List<String> four = new ArrayList<String>();
	     four.add("Rachel");
	     four.add("42");
	     four.add("Testing");
	     four.add("60000");
	     
	     List<String> five =new ArrayList<String>();
	     five.add("Mounica");
	     five.add("24");
	     five.add("Learning & Development");
	     five.add("50000");
	     
	     map.put("100", one);
	     map.put("101",two);
	     map.put("102", three);
	     map.put("103", four);
	     map.put("104", five);
	     
	     
	     out.println("<html><head><style>"
	      		+ "table {\r\n" + 
	      		"    border-collapse: collapse;\r\n" + 
	      		"    width: 100%;\r\n" + 
	      		"}\r\n" + 
	      		"\r\n" + 
	      		"th, td {\r\n" + 
	      		"    text-align: left;\r\n" + 
	      		"    padding: 8px;\r\n" + 
	      		"}\r\n" + 
	      		"\r\n" 
	      		+ "</style></head><body><table>");
	      out.println("<tr>");
	      out.println("<th>Emp Id</th>");
	      out.println("<th>Emp Name</th>");
	      out.println("<th>Emp Age</th>");
	      out.println("<th>Emp Dept</th>");
	      out.println("<th>Emp Salary</th>");
	     out.println("</tr>");

	      for (Map.Entry<String, List<String>> entry : map.entrySet()) {
	          String key = entry.getKey();
	          List<String> values = entry.getValue();
	          
	          out.println("<tr class=\"wrap\">");
	          out.println("<td>"+key+"</td>");
	          out.println("<td>"+values.get(0)+"</td>");
	          out.println("<td>"+values.get(1)+"</td>");
	          out.println("<td>"+values.get(2)+"</td>");
	          out.println("<td>"+values.get(3)+"</td>");
	         
	        
	         out.println("</tr>");
	      
	      
	      
	      }
	 	
	        out.println("</table></body></html>");
		
		
		
		

//		String pass=request.getParameter("pass");
//		
//		if(pass.equals("1234"))
//		{		
//			RequestDispatcher rd=request.getRequestDispatcher("data");
//		    rd.forward(request, response);
//		 }
//		else
//		{
//			out.println("Sorry Wrong Password");
//			RequestDispatcher rd=request.getRequestDispatcher("/index.html");
//			rd.include(request, response);
//		}
//	

}
}