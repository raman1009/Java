package com.rb.dao;

import java.util.ArrayList;
import java.util.List;

import com.rb.service.Bus;

public class BusesDataBase 
{

	public static  List<Bus>  getBuses()
	{
		Bus bus1= new Bus();
		bus1.setSource("Kakinad");
		bus1.setDestination("Hyderabad");

		Bus bus2= new Bus();
		bus2.setSource("Rajahmundry");
		bus2.setDestination("Bangalore");

		List<Bus> busList = new ArrayList<Bus>();

		busList.add(bus1);
		busList.add(bus2);

		return busList;
	}
}
