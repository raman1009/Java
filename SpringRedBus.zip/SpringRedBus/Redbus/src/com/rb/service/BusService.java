package com.rb.service;

import java.util.List;

import com.rb.dao.BusesDataBase;

public class BusService
{

	public List<Bus> getAllBuses(String source, String destination) 
	{
		BusesDataBase db = new BusesDataBase();
		List<Bus> allBusesInfo = db.getBuses();
		return allBusesInfo;
	}
}
