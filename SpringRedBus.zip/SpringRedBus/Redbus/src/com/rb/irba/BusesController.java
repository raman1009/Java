package com.rb.irba;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractCommandController;
import org.springframework.web.servlet.mvc.AbstractController;

import com.rb.service.Bus;
import com.rb.service.BusService;

public class BusesController extends AbstractController
{

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest req, HttpServletResponse resp) throws Exception {


		String source = req.getParameter("source");
		String destination = req.getParameter("destination");

		BusService busService = new BusService();
		List<Bus> busesList = busService.getAllBuses(source, destination);

		ModelAndView mav= new ModelAndView();
		mav.addObject("busesList",busesList);
		
		
		
		mav.setViewName("buses");
		return mav;
	}


}
