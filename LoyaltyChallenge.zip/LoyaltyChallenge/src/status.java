

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class status extends HttpServlet {
	private static final long serialVersionUID = 1L;

  
//    public status() { }
        


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out= response.getWriter();
		
	String name= request.getParameter("name");
	int miles= Integer.parseInt(request.getParameter("miles"));
		int duration= Integer.parseInt(request.getParameter("duration"));
		String status= request.getParameter("status");
		out.println("<body bgcolor= '#FFF5EE'>");
		
		out.println("Hello"+" "+name);
		out.println("<br>");
		
		if((miles>25000) && (duration<12) && (status.equals("None")))
		{
		out.println("Your current Status is: Bronze");
	}
	
	else
		
		if((miles>25000) && (duration>=12 && duration<=24) && (status.equals("bronze")))
		{
				out.println("Your current status is: Silver");
		}
		else
			if((miles>35000) && (duration>24 && duration<=36) && (status.equals("silver")))
				{
					out.println("Your current status is: Gold");
			}
			else
				if((miles>50000) && (duration>36) && (status.equals("gold")))
			{
					out.println("Your current status is: Platinum");
					}
				else
					if( (status.equals("platinum")) && (miles<50000))
				{
					out.println("You are degraded to Gold Status");
				}
					else if ((status.equals("gold")) && (miles<50000))
					{
						out.println("You are degraded to Bronze Status");
					}
					else if ( (status.equals("silver")) && (miles<35000))
					{
						out.println("You are degraded to Bronze Status");
					}
					else if(miles<25000)
					{
						out.println("Your Current Status is: None");
					}
				else
				{
					out.println("You Entered Wrong Input");
				}
		
	}

}
